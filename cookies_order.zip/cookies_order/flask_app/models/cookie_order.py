# import the function that will return an instance of a connection
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Cookie_order:

    DB = "cookies_db"

    def __init__(self,cookie_order):

        self.id = cookie_order["id"]
        self.name = cookie_order["name"]
        self.cookie_type = cookie_order["cookie_type"]
        self.num_boxes = cookie_order["num_boxes"]
        self.created_at = cookie_order["created_at"]
        self.updated_at = cookie_order["updated_at"]

    @classmethod
    def is_valid(cls, cookie_order):
        valid = True

        if len(cookie_order["name"]) <= 0 or len(cookie_order["cookie_type"]) <= 0 or len(cookie_order["num_boxes"]) <= 0:
            valid = False
            flash("All fields required")
            return valid
        if len(cookie_order["name"]) < 2:
            valid = False
            flash("Name must be at least 2 characters")
        if len(cookie_order["cookie_type"]) < 2:
            valid = False
            flash("Cookie type must be at least 2 characters")
        if int(cookie_order["num_boxes"]) <= 0:
            valid = False
            flash("Please enter a valid number of boxes.")
        return valid
    
    @classmethod
    def get_by_id(cls, order_id):
        query = "SELECT * from cookies_order WHERE id = %(id)s;"
        data = {
            "id": order_id
        }
        result = connectToMySQL(cls.DB).query_db(query, data)
        if result:
            order = result[0]
            return order

        return False

    @classmethod
    def get_all(cls):
        query = "SELECT * from cookies_order;"
        orders_data = connectToMySQL(cls.DB).query_db(query)

        orders = []
        for order in orders_data:
            orders.append(cls(order))

        return orders

    @classmethod
    def create(cls, cookie_order):

        query = """
                INSERT into cookies_order (name, cookie_type, num_boxes)
                VALUES (%(name)s, %(cookie_type)s, %(num_boxes)s);"""

        result = connectToMySQL(cls.DB).query_db(query, cookie_order)
        return result
    
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL(cls.DB).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])
    
    @classmethod
    def get_user_cookies(cls,data):
        query = "SELECT * FROM users LEFT JOIN cookies ON users.id= cookies.user_id"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        for row in results:
            results.append( cls(results) )
        return results
   
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM cookies_order WHERE id = %(id)s;"
        results = connectToMySQL(cls.DB).query_db(query,data)
        return cls( results[0] )

    @classmethod
    def update(cls, cookie_order):

        query = """
                UPDATE cookies_order
                SET name = %(name)s, cookie_type = %(cookie_type)s, num_boxes = %(num_boxes)s
                WHERE id = %(id)s;"""

        result = connectToMySQL(cls.DB).query_db(query, cookie_order)
        return result
    